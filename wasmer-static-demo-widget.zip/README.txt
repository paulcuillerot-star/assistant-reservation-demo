# Démo Wasmer — Widget de chat (statique)
Ce dossier `public/` contient une démo **100% statique** du widget. Aucune dépendance serveur n’est requise pour l’aperçu.

## Déploiement (Wasmer)
1. Installer & se connecter : `wasmer login`
2. Créer un projet modèle *site statique* :

```bash
mkdir demo-widget && cd demo-widget
wasmer deploy --template=static-website
```

3. Copiez le contenu de ce `public/` dans le `public/` généré par Wasmer (remplacez les fichiers).
4. Déployez :

```bash
wasmer deploy
```

✅ Vous obtenez une URL publique du type `https://<app>-<owner>.wasmer.app`.

## Tester en local
```
wasmer run .
# puis ouvrez http://localhost:8080
```

## Brancher votre n8n (plus tard)
Dans `public/index.html`, passez `webhookUrl` à l’URL de votre Webhook n8n (POST). Si `webhookUrl` est vide, le widget répond avec des **réponses de démo**.
